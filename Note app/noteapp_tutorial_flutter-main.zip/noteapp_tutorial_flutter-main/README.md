# notely

A new Flutter project.

## Getting Started

This is a code repository for the tutorials I am creating for Flutter. Youtube link: https://www.youtube.com/playlist?list=PLSzAduAyNr2VsPwUwIKWmxtYZo7bJ9r-8

We will learn:

- How to structure flutter project and separate views into small widgets
- How to use bloc pattern for states and events to create a robust application
- How to use an offline database to store data.
- And many more...

Design Credit: https://dribbble.com/shots/11875872-A-simple-and-lightweight-note-app
