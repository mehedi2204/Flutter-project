# flutter_bmi_calculator

![WhatsApp Image 2021-02-03 at 1 47 05 PM](https://user-images.githubusercontent.com/66554769/106717940-5ec9b580-6626-11eb-8911-a0c24de867cc.jpeg)
![WhatsApp Image 2021-02-03 at 1 47 06 PM](https://user-images.githubusercontent.com/66554769/106717941-5f624c00-6626-11eb-8575-694ffa55ac62.jpeg)
