# E-commerce Clone App UI

- [Support me on Patreon](https://www.patreon.com/sopheamenvan?fan_landing=true)
- [Watch on Youtube](https://www.youtube.com/watch?v=ZT4KJKzxUj0)

![App UI](https://user-images.githubusercontent.com/16510597/113294576-5b4e6400-9321-11eb-8940-68e1223b4b0f.jpg)

## GET A Full Project Source Code

- [Download Source Code](https://www.patreon.com/posts/e-commerce-ui-49272877)

![App UI](https://user-images.githubusercontent.com/16510597/113295090-f0e9f380-9321-11eb-8736-9ee5c291e471.png)

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
# app.mobile.ecommerce-clone-app-ui
