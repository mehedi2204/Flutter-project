<img width="1048" alt="Screenshot 2021-04-28 at 3 00 49 PM" src="https://user-images.githubusercontent.com/28984101/117434304-22219900-af4a-11eb-9520-8f29e9c7fffc.png">
# flutter_ecommerce_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
