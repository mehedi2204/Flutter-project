import 'package:flutter/material.dart';

Color kPrimaryColor = Color(0xff333742);
Color kAccentColor = Color(0xff454D5A);
