import 'package:flutter/cupertino.dart';

final kMenuIcon = Image.asset("assets/icons/menu.png");
final kSearchIcon = Image.asset("assets/icons/search.png");
final kSortIcon = Image.asset("assets/icons/sort.png");
final kNotifecationIcon = Image.asset("assets/icons/notifecation.png");
final kHomeIcon = Image.asset("assets/icons/home.png");
final kProfileIcon = Image.asset("assets/icons/profile.png");
final kBasketIcon = Image.asset("assets/icons/basket.png");
final kHeadPhoneImage = Image.asset("assets/headphone.png");
final kHeartImage = Image.asset("assets/icons/heart.png");
final kStarImage = Image.asset("assets/icons/star.png");
final kEyeImage = Image.asset("assets/icons/eye.png");



