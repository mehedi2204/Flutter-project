package com.example.electronics_e_commerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
