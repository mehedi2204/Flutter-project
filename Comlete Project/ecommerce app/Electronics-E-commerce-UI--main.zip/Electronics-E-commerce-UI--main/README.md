# electronics_e_commerce

A new Flutter project.

## Watch on youtube : https://www.youtube.com/watch?v=5gYeuc6wuNQ

![5915450-ai (1) (1) (1)](https://user-images.githubusercontent.com/67558182/132749782-a0f1442d-1980-4ed0-92d7-f2e3d259b029.png)
